
var total=0;
//document.getElementById("status").innerHTML =
//"<p>&copy;  " + new Date().getFullYear() + " Total Bolcked XSS : " +total+".</p>";